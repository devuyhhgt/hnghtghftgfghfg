package com.devusql;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends AppCompatActivity {
	private Timer _timer = new Timer();
	
	private LinearLayout l_1;
	private TextView eyes;
	private CardView cv;
	private LinearLayout cv_inside;
	private LinearLayout usr_nameid;
	private LinearLayout mt2;
	private LinearLayout usr_mailid;
	private LinearLayout mt3;
	private LinearLayout usr_passid;
	private LinearLayout log_l;
	private LinearLayout usr_img;
	private LinearLayout usr_namel;
	private EditText usr_name;
	private LinearLayout mail;
	private LinearLayout usr_maill;
	private EditText usr_mail;
	private LinearLayout pass;
	private LinearLayout usr_passl;
	private EditText usr_pass;
	private LinearLayout eye;
	private ImageView imageview1;
	private Button log;
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		l_1 = (LinearLayout) findViewById(R.id.l_1);
		eyes = (TextView) findViewById(R.id.eyes);
		cv = (CardView) findViewById(R.id.cv);
		cv_inside = (LinearLayout) findViewById(R.id.cv_inside);
		usr_nameid = (LinearLayout) findViewById(R.id.usr_nameid);
		mt2 = (LinearLayout) findViewById(R.id.mt2);
		usr_mailid = (LinearLayout) findViewById(R.id.usr_mailid);
		mt3 = (LinearLayout) findViewById(R.id.mt3);
		usr_passid = (LinearLayout) findViewById(R.id.usr_passid);
		log_l = (LinearLayout) findViewById(R.id.log_l);
		usr_img = (LinearLayout) findViewById(R.id.usr_img);
		usr_namel = (LinearLayout) findViewById(R.id.usr_namel);
		usr_name = (EditText) findViewById(R.id.usr_name);
		mail = (LinearLayout) findViewById(R.id.mail);
		usr_maill = (LinearLayout) findViewById(R.id.usr_maill);
		usr_mail = (EditText) findViewById(R.id.usr_mail);
		pass = (LinearLayout) findViewById(R.id.pass);
		usr_passl = (LinearLayout) findViewById(R.id.usr_passl);
		usr_pass = (EditText) findViewById(R.id.usr_pass);
		eye = (LinearLayout) findViewById(R.id.eye);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		log = (Button) findViewById(R.id.log);
		
		eye.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (eyes.getText().toString().equals("show")) {
					imageview1.setImageResource(R.drawable.ic_visibility_off_black);
					eyes.setText("hide");
					usr_pass.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
				}
				else {
					imageview1.setImageResource(R.drawable.ic_remove_red_eye_black);
					eyes.setText("show");
					usr_pass.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
				}
			}
		});
		
		log.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				log.setScaleX((float)(1.2d));
				log.setScaleY((float)(1.2d));
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								log.setScaleX((float)(1.0d));
								log.setScaleY((float)(1.0d));
							}
						});
					}
				};
				_timer.schedule(timer, (int)(122));
			}
		});
	}
	
	private void initializeLogic() {
		SketchwareUtil.showMessage(getApplicationContext(), "WelcomeUser");
		log.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFCE93D8));
		eyes.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}